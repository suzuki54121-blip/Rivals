-- RivalsStyleArena prototype. Server owns combat, match state and player stats.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local DataStoreService = game:GetService("DataStoreService")

local DATASTORE_NAME = "RivalsStyleArena_PlayerData_v1"
local ROUND_SECONDS = 90
local COUNTDOWN_SECONDS = 5
local RESULT_SECONDS = 5
local DAMAGE = 25
local HEADSHOT_MULTIPLIER = 1.5
local WEAPON_RANGE = 500
local FIRE_INTERVAL = 0.18
local MAX_CAMERA_OFFSET = 12
local MIN_DIRECTION_DOT = math.cos(math.rad(80))
local AUTOSAVE_SECONDS = 60

local store = DataStoreService:GetDataStore(DATASTORE_NAME)

-- Create remotes on the server; clients WaitForChild these instances.
local remotes = ReplicatedStorage:FindFirstChild("Remotes")
if not remotes then
    remotes = Instance.new("Folder")
    remotes.Name = "Remotes"
    remotes.Parent = ReplicatedStorage
end

local function getRemote(name, className)
    local existing = remotes:FindFirstChild(name)
    if existing and existing.ClassName == className then
        return existing
    end
    if existing then existing:Destroy() end
    local item = Instance.new(className)
    item.Name = name
    item.Parent = remotes
    return item
end

local FireWeapon = getRemote("FireWeapon", "RemoteEvent")
local MatchUpdate = getRemote("MatchUpdate", "RemoteEvent")
local GetMatchState = getRemote("GetMatchState", "RemoteFunction")
local GetPlayerData = getRemote("GetPlayerData", "RemoteFunction")

local lobbySpawn = workspace:WaitForChild("LobbySpawn")
local arena = workspace:WaitForChild("Arena")
local spawn1 = arena:WaitForChild("Spawn1")
local spawn2 = arena:WaitForChild("Spawn2")

local defaults = { Kills = 0, Deaths = 0, Wins = 0, Level = 1, Coins = 0 }
local sessions = {}
local lastShot = {}
local queue = {}
local activeMatch = nil
local nextMatchId = 0

local function finite(n)
    return typeof(n) == "number" and n == n and math.abs(n) < 1e6
end

local function validVector(v)
    return typeof(v) == "Vector3"
        and finite(v.X) and finite(v.Y) and finite(v.Z)
end

local function createStats(player, data)
    local leaderstats = Instance.new("Folder")
    leaderstats.Name = "leaderstats"
    leaderstats.Parent = player

    for _, key in ipairs({"Kills", "Deaths", "Wins"}) do
        local value = Instance.new("IntValue")
        value.Name = key
        value.Value = data[key]
        value.Parent = leaderstats
    end

    local profile = Instance.new("Folder")
    profile.Name = "Profile"
    profile.Parent = player

    for _, key in ipairs({"Level", "Coins"}) do
        local value = Instance.new("IntValue")
        value.Name = key
        value.Value = data[key]
        value.Parent = profile
    end
end

local function snapshot(player)
    local ls = player:FindFirstChild("leaderstats")
    local profile = player:FindFirstChild("Profile")
    if not ls or not profile then return nil end
    return {
        Kills = ls.Kills.Value,
        Deaths = ls.Deaths.Value,
        Wins = ls.Wins.Value,
        Level = profile.Level.Value,
        Coins = profile.Coins.Value,
    }
end

local function loadPlayer(player)
    local key = "Player_" .. player.UserId
    local loadedData
    for attempt = 1, 3 do
        local ok, result = pcall(function()
            return store:GetAsync(key)
        end)
        if ok then
            loadedData = type(result) == "table" and result or {}
            break
        end
        warn(("DataStore load failed for %d (attempt %d): %s")
            :format(player.UserId, attempt, tostring(result)))
        task.wait(attempt * 2)
    end

    if not loadedData then
        if player.Parent == Players then
            player:Kick("データを読み込めませんでした。時間をおいて再接続してください。")
        end
        return
    end

    local clean = {}
    for keyName, defaultValue in pairs(defaults) do
        local value = loadedData[keyName]
        if not finite(value) or value < 0 then value = defaultValue end
        clean[keyName] = math.floor(math.clamp(value, 0, 1000000000))
    end

    if player.Parent ~= Players then return end
    createStats(player, clean)
    sessions[player] = { loaded = true, saving = false }
    player:SetAttribute("InMatch", false)
end

local function savePlayer(player)
    local session = sessions[player]
    if not session or not session.loaded or session.saving then return end
    local data = snapshot(player)
    if not data then return end

    session.saving = true
    local key = "Player_" .. player.UserId
    local ok, err = pcall(function()
        -- Prototype assumes one active server session per player.
        -- Production games should add a session-lock / reconciliation strategy.
        store:UpdateAsync(key, function(_old)
            return data
        end)
    end)
    session.saving = false
    if not ok then
        warn(("DataStore save failed for %d: %s")
            :format(player.UserId, tostring(err)))
    end
end

local function teleportTo(player, spawnPart)
    if player.Parent ~= Players then return false end
    local character = player.Character
    if not character then
        player:LoadCharacter()
        character = player.CharacterAdded:Wait()
    end
    if not character or not character.Parent then return false end
    character:PivotTo(spawnPart.CFrame + Vector3.new(0, 3, 0))
    return true
end

local function alive(player)
    local character = player.Character
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    return humanoid and humanoid.Health > 0, humanoid, character
end

local function clearMatchState(player)
    player:SetAttribute("InMatch", false)
    player:SetAttribute("MatchId", nil)
end

local function finishMatch(match, winner, reason)
    if match.finished then return end
    match.finished = true

    for _, connection in ipairs(match.connections) do
        connection:Disconnect()
    end
    table.clear(match.connections)

    for _, player in ipairs(match.players) do
        if player.Parent == Players then
            local result = "DRAW"
            if winner then result = player == winner and "VICTORY" or "DEFEAT" end
            MatchUpdate:FireClient(player, "Result", result, reason)

            if winner == player and not match.winAwarded then
                match.winAwarded = true
                local ls = player:FindFirstChild("leaderstats")
                local profile = player:FindFirstChild("Profile")
                if ls and profile and sessions[player] then
                    ls.Wins.Value += 1
                    profile.Coins.Value += 50
                    local needed = profile.Level.Value * 100
                    while profile.Coins.Value >= needed do
                        profile.Coins.Value -= needed
                        profile.Level.Value += 1
                        needed = profile.Level.Value * 100
                    end
                end
            end
        end
    end

    task.wait(RESULT_SECONDS)

    for _, player in ipairs(match.players) do
        if player.Parent == Players then
            clearMatchState(player)
            teleportTo(player, lobbySpawn)
            MatchUpdate:FireClient(player, "Lobby")
        end
    end

    if activeMatch == match then activeMatch = nil end
end

local function startMatch(p1, p2)
    if activeMatch or p1.Parent ~= Players or p2.Parent ~= Players then return end
    if not sessions[p1] or not sessions[p2] then return end

    nextMatchId += 1
    local match = {
        id = tostring(nextMatchId),
        players = {p1, p2},
        finished = false,
        started = false,
        connections = {},
    }
    activeMatch = match

    for _, player in ipairs(match.players) do
        player:SetAttribute("MatchId", match.id)
        player:SetAttribute("InMatch", false)
    end

    teleportTo(p1, spawn1)
    teleportTo(p2, spawn2)

    for count = COUNTDOWN_SECONDS, 1, -1 do
        if match.finished then return end
        if p1.Parent ~= Players or p2.Parent ~= Players then
            local remaining = p1.Parent == Players and p1 or p2
            finishMatch(match, remaining, "OpponentLeft")
            return
        end
        for _, player in ipairs(match.players) do
            MatchUpdate:FireClient(player, "Countdown", count)
        end
        task.wait(1)
    end
    if match.finished then return end

    match.started = true
    for _, player in ipairs(match.players) do
        player:SetAttribute("InMatch", true)
        MatchUpdate:FireClient(player, "Started", ROUND_SECONDS)
    end

    local function hookCharacter(player, character)
        local humanoid = character:WaitForChild("Humanoid", 10)
        if not humanoid or match.finished then return end
        local connection = humanoid.Died:Connect(function()
            if match.finished or not match.started then return end
            local opponent = player == p1 and p2 or p1
            if opponent.Parent == Players then
                finishMatch(match, opponent, "Elimination")
            else
                finishMatch(match, nil, "OpponentLeft")
            end
        end)
        table.insert(match.connections, connection)
    end

    for _, player in ipairs(match.players) do
        if player.Character then hookCharacter(player, player.Character) end
        table.insert(match.connections, player.CharacterAdded:Connect(function(character)
            hookCharacter(player, character)
        end))
    end

    for remaining = ROUND_SECONDS, 1, -1 do
        if match.finished then break end
        for _, player in ipairs(match.players) do
            if player.Parent == Players then
                MatchUpdate:FireClient(player, "Timer", remaining)
            end
        end
        task.wait(1)
    end

    if not match.finished then
        local aAlive, aHumanoid = alive(p1)
        local bAlive, bHumanoid = alive(p2)
        local h1 = aAlive and aHumanoid.Health or 0
        local h2 = bAlive and bHumanoid.Health or 0
        local winner
        if p1.Parent == Players and p2.Parent ~= Players then
            winner = p1
        elseif p2.Parent == Players and p1.Parent ~= Players then
            winner = p2
        elseif h1 > h2 then
            winner = p1
        elseif h2 > h1 then
            winner = p2
        end
        finishMatch(match, winner, "TimeUp")
    end
end

-- Server-authoritative shooting. Client-sent damage/target is never accepted.
FireWeapon.OnServerEvent:Connect(function(player, cameraOrigin, cameraDirection)
    if player:GetAttribute("InMatch") ~= true then return end
    if not validVector(cameraOrigin) or not validVector(cameraDirection) then return end

    local mag = cameraDirection.Magnitude
    if mag < 0.99 or mag > 1.01 then return end

    local isAlive, humanoid, character = alive(player)
    if not isAlive then return end
    local head = character:FindFirstChild("Head")
    if not head then return end

    local now = os.clock()
    if now - (lastShot[player] or 0) < FIRE_INTERVAL then return end
    if (cameraOrigin - head.Position).Magnitude > MAX_CAMERA_OFFSET then return end

    local direction = cameraDirection.Unit
    if head.CFrame.LookVector:Dot(direction) < MIN_DIRECTION_DOT then return end

    lastShot[player] = now
    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances = {character}
    params.IgnoreWater = true

    -- Use server-observed character position as ray origin, not the arbitrary client origin.
    local result = workspace:Raycast(head.Position, direction * WEAPON_RANGE, params)
    if not result then return end

    local instance = result.Instance
    local model = instance:FindFirstAncestorOfClass("Model")
    local target = model and Players:GetPlayerFromCharacter(model)
    if not target or target == player then return end
    if target:GetAttribute("InMatch") ~= true then return end
    if target:GetAttribute("MatchId") ~= player:GetAttribute("MatchId") then return end

    local targetHumanoid = model:FindFirstChildOfClass("Humanoid")
    if not targetHumanoid or targetHumanoid.Health <= 0 then return end

    local damage = DAMAGE
    if instance.Name == "Head" then damage *= HEADSHOT_MULTIPLIER end

    local wasAlive = targetHumanoid.Health > 0
    targetHumanoid:TakeDamage(damage)

    if wasAlive and targetHumanoid.Health <= 0 then
        local ls = player:FindFirstChild("leaderstats")
        local victimStats = target:FindFirstChild("leaderstats")
        local profile = player:FindFirstChild("Profile")
        if ls and victimStats and profile and sessions[player] and sessions[target] then
            ls.Kills.Value += 1
            victimStats.Deaths.Value += 1
            profile.Coins.Value += 5
        end
    end
end)

GetMatchState.OnServerInvoke = function(player)
    local match = activeMatch
    if not match or not table.find(match.players, player) then
        return {state = "Lobby"}
    end
    return {
        state = match.started and "InMatch" or "Countdown",
        matchId = match.id,
        duration = ROUND_SECONDS,
    }
end

GetPlayerData.OnServerInvoke = function(player)
    if not sessions[player] or not sessions[player].loaded then return nil end
    return snapshot(player)
end

Players.PlayerAdded:Connect(function(player)
    player:SetAttribute("InMatch", false)
    task.spawn(loadPlayer, player)
end)

Players.PlayerRemoving:Connect(function(player)
    local match = activeMatch
    if match and not match.finished and table.find(match.players, player) then
        local opponent = match.players[1] == player and match.players[2] or match.players[1]
        if opponent.Parent == Players then
            task.spawn(finishMatch, match, opponent, "OpponentLeft")
        else
            task.spawn(finishMatch, match, nil, "OpponentLeft")
        end
    end
    savePlayer(player)
    sessions[player] = nil
    lastShot[player] = nil
    for i = #queue, 1, -1 do
        if queue[i] == player then table.remove(queue, i) end
    end
end)

-- Include players who were already present if this script starts during Studio testing.
for _, player in ipairs(Players:GetPlayers()) do
    player:SetAttribute("InMatch", false)
    task.spawn(loadPlayer, player)
end

task.spawn(function()
    while true do
        task.wait(1)
        if not activeMatch then
            -- Drop stale queue entries and add loaded, idle players.
            for i = #queue, 1, -1 do
                local p = queue[i]
                if p.Parent ~= Players or not sessions[p] or p:GetAttribute("InMatch") then
                    table.remove(queue, i)
                end
            end
            for _, player in ipairs(Players:GetPlayers()) do
                if sessions[player] and not player:GetAttribute("InMatch")
                    and not table.find(queue, player) then
                    table.insert(queue, player)
                end
            end
            if #queue >= 2 then
                local p1 = table.remove(queue, 1)
                local p2 = table.remove(queue, 1)
                task.spawn(startMatch, p1, p2)
            end
        end
    end
end)

task.spawn(function()
    while true do
        task.wait(AUTOSAVE_SECONDS)
        for player, session in pairs(sessions) do
            if session.loaded then task.spawn(savePlayer, player) end
        end
    end
end)

game:BindToClose(function()
    local pending = 0
    local finished = Instance.new("BindableEvent")
    for player in pairs(sessions) do
        pending += 1
        task.spawn(function()
            savePlayer(player)
            pending -= 1
            if pending == 0 then finished:Fire() end
        end)
    end
    if pending > 0 then
        -- Safety timeout avoids hanging shutdown forever.
        task.delay(25, function() finished:Fire() end)
        finished.Event:Wait()
    end
    finished:Destroy()
end)
