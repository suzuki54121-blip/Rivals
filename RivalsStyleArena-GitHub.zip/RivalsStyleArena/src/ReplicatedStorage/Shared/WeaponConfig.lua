-- Client convenience settings only.
-- The server keeps authoritative combat limits in Main.server.lua.
return {
    FireInterval = 0.18,
}
