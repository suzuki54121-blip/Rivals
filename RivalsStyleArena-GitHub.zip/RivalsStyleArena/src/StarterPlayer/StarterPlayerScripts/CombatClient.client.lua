local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer
local fireWeapon = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("FireWeapon")
local config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("WeaponConfig"))
local lastShot = 0

local function playLocalShotEffect()
    -- TODO: Attach ParticleEmitter / Sound to your weapon's Muzzle attachment.
    -- Keep this cosmetic: never decide hits or damage on the client.
end

local function shoot()
    if player:GetAttribute("InMatch") ~= true then return end
    local now = os.clock()
    if now - lastShot < config.FireInterval then return end
    lastShot = now

    local camera = workspace.CurrentCamera
    if not camera then return end

    local origin = camera.CFrame.Position
    local direction = camera.CFrame.LookVector
    playLocalShotEffect()
    fireWeapon:FireServer(origin, direction)
end

UserInputService.InputBegan:Connect(function(input, processed)
    if processed then return end
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        shoot()
    end
end)

-- For mobile, call shoot() from a GUI button callback.
