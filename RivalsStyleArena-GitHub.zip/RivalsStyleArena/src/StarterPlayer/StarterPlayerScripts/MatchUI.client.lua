local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local matchUpdate = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("MatchUpdate")

local gui = Instance.new("ScreenGui")
gui.Name = "MatchUI"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local label = Instance.new("TextLabel")
label.Name = "Status"
label.Size = UDim2.fromScale(0.5, 0.1)
label.Position = UDim2.fromScale(0.25, 0.06)
label.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
label.BackgroundTransparency = 0.2
label.TextColor3 = Color3.new(1, 1, 1)
label.TextScaled = true
label.Font = Enum.Font.GothamBold
label.Visible = false
label.Parent = gui

matchUpdate.OnClientEvent:Connect(function(action, value, _detail)
    if action == "Countdown" then
        label.Visible = true
        label.Text = "MATCH STARTS IN " .. tostring(value)
        label.TextColor3 = Color3.new(1, 1, 1)
    elseif action == "Started" then
        label.Visible = true
        label.Text = "FIGHT!"
    elseif action == "Timer" then
        label.Visible = true
        label.Text = "TIME: " .. tostring(value)
    elseif action == "Result" then
        label.Visible = true
        label.Text = tostring(value)
        if value == "VICTORY" then
            label.TextColor3 = Color3.fromRGB(80, 255, 120)
        elseif value == "DEFEAT" then
            label.TextColor3 = Color3.fromRGB(255, 80, 80)
        else
            label.TextColor3 = Color3.new(1, 1, 1)
        end
    elseif action == "Lobby" then
        label.Visible = false
    end
end)
