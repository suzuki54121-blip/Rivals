# RivalsStyleArena (Roblox Studio / Luau)

Rivals風のオンラインFPS/TPSを学習・試作するためのサーバー主導型テンプレートです。Robloxの既存ゲーム「Rivals」の公式コードではなく、独立したサンプル実装です。

## 機能

- 1v1マッチメイキング（同一Robloxサーバー内）
- 5秒カウントダウン、90秒ラウンド、結果表示、5秒後のロビー復帰
- サーバー側レイキャスト、連射クールダウン、射撃要求の型・位置・方向検証
- サーバー側キル/デス/勝利/コイン/レベル管理
- DataStoreの読み込み、定期保存、退出時・サーバー終了時の保存
- クライアント側の即時射撃演出用フックと最低限の試合UI

## 注意

これは**試作品**です。本番公開前に、複数サーバー間マッチメイキング、セッションロック、武器ごとの弾薬/リロード、アンチチート監視、通信量、切断・再接続、2v2のチーム処理、履歴を使ったサーバー側ラグ補正を追加・テストしてください。クライアントのエフェクトは命中結果を決定しません。

## セットアップ

### 方法A: Roblox Studioに手動で貼り付ける

1. Roblox Studioで新しいBaseplateを作成します。
2. `ServerScriptService` に `Main.server.lua` という名前の `Script` を作り、`src/ServerScriptService/Main.server.lua` を貼り付けます。
3. `StarterPlayer > StarterPlayerScripts` に `CombatClient.client.lua` と `MatchUI.client.lua` の `LocalScript` を作り、対応するファイル内容を貼り付けます。
4. `Workspace` に次のPartを作成します（Anchored=true推奨）。
   - `LobbySpawn`
   - `Arena` というFolder
   - `Arena` 内に `Spawn1` と `Spawn2`
5. `Spawn1` と `Spawn2` は十分に離して配置し、床や壁などのマップを作成します。
6. ゲームを公開し、テスト用エクスペリエンスで `Game Settings > Security > Enable Studio Access to API Services` を必要に応じて有効にします。本番データと開発データを混在させないでください。
7. Studioの **Test > Start** からサーバーを起動し、Playersを2人にして試します。

`Main.server.lua` が `ReplicatedStorage/Remotes` とRemoteインスタンスを起動時に作成するため、手動作成は不要です。

### 方法B: Rojoを使う

リポジトリの `default.project.json` を使ってRojoで同期できます。Rojoが未導入の場合は、まずRojo公式ドキュメントを確認してください。手動セットアップの場合は `default.project.json` は不要です。

## GitHubにアップロード

1. GitHubで新しい空のリポジトリを作ります。
2. このZIPを展開し、ファイルをリポジトリにアップロードします。
3. またはローカルで次を実行します。

```bash
git init
git add .
git commit -m "Initial Roblox arena prototype"
git branch -M main
git remote add origin https://github.com/YOUR-NAME/YOUR-REPOSITORY.git
git push -u origin main
```

`YOUR-NAME` と `YOUR-REPOSITORY` は自分のGitHub情報に置き換えてください。

## 通信仕様

| Remote | 方向 | 用途 |
|---|---|---|
| `FireWeapon` | Client → Server | `origin`, `direction` を送る射撃要求。サーバーで再検証 |
| `MatchUpdate` | Server → Client | カウントダウン、開始、残り時間、結果、ロビー状態 |
| `GetMatchState` | Client → Server | 現在のプレイヤー向け試合状態を問い合わせ |
| `GetPlayerData` | Client → Server | サーバーが保持する表示用統計を問い合わせ |

クライアントから送られたダメージ、命中相手、勝敗、コイン数は採用しません。RemoteFunctionは読み取り専用の問い合わせに限定しています。

## 保存データ

`RivalsStyleArena_PlayerData_v1` に `Kills`, `Deaths`, `Wins`, `Level`, `Coins` を保存します。スキーマを変更する場合は、バージョンを上げるか、データ移行処理を実装してください。

## ラグ補正について

このサンプルはサーバーが検証したキャラクター頭部位置から現在のワールドに対してRaycastします。**過去の位置履歴を使う本格的なラグ補正（rewind）は実装していません**。履歴の保存、射撃時刻の検証、巻き戻し上限、遮蔽物の再評価をサーバー側で追加してください。
